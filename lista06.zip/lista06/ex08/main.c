/*8. Radical é o elemento que contém o significado básico em uma palavra e do qual é possível
constituir uma família de palavras. Em um verbo regular, o radical é a parte invariante, que dá
origem a todas as conjugações. Escreva um programa que leia um verbo regular terminado em
“AR”, obtenha o radical e retorne a conjugação nos seguintes tempos verbais:
1. Presente do indicativo;
2. Pretérito perfeito do indicativo;
3. Futuro de presente do indicativo;*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>